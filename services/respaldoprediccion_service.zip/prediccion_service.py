from datetime import datetime, date, timedelta, timezone

import numpy as np

from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


# ============================================================
# CONFIGURACIÓN
# ============================================================

MIN_DIAS_ENTRENAMIENTO = 28
MIN_REGISTROS_MODELO = 14
DIAS_PREDICCION = 7


# ============================================================
# CONVERSIÓN DE FECHAS
# ============================================================

def _convertir_fecha(fecha):
    """
    Convierte diferentes formatos de fecha a datetime.

    Las fechas con zona horaria se convierten a UTC y después
    se eliminan los datos de zona horaria para trabajar de
    forma consistente dentro del modelo.
    """

    if fecha is None:
        return None

    if isinstance(fecha, datetime):

        if fecha.tzinfo is not None:
            fecha = fecha.astimezone(timezone.utc)
            fecha = fecha.replace(tzinfo=None)

        return fecha

    if isinstance(fecha, date):
        return datetime.combine(
            fecha,
            datetime.min.time()
        )

    if hasattr(fecha, "to_datetime"):

        try:
            fecha_convertida = fecha.to_datetime()

            if fecha_convertida.tzinfo is not None:
                fecha_convertida = (
                    fecha_convertida
                    .astimezone(timezone.utc)
                    .replace(tzinfo=None)
                )

            return fecha_convertida

        except Exception:
            pass

    if hasattr(fecha, "timestamp"):

        try:
            return datetime.fromtimestamp(
                fecha.timestamp(),
                tz=timezone.utc
            ).replace(tzinfo=None)

        except Exception:
            pass

    if isinstance(fecha, str):

        try:
            fecha_convertida = datetime.fromisoformat(
                fecha.replace("Z", "+00:00")
            )

            if fecha_convertida.tzinfo is not None:
                fecha_convertida = (
                    fecha_convertida
                    .astimezone(timezone.utc)
                    .replace(tzinfo=None)
                )

            return fecha_convertida

        except ValueError:
            return None

    return None


# ============================================================
# NORMALIZAR HISTORIAL
# ============================================================

def _normalizar_historial(historial_producto):

    registros = []

    for venta in historial_producto:

        fecha = _convertir_fecha(
            getattr(venta, "fecha", None)
        )

        if fecha is None:
            continue

        try:
            cantidad = float(
                getattr(venta, "cantidad", 0)
            )
        except (TypeError, ValueError):
            continue

        if cantidad < 0:
            continue

        registros.append(
            {
                "fecha": fecha,
                "cantidad": cantidad
            }
        )

    registros.sort(
        key=lambda registro: registro["fecha"]
    )

    return registros


# ============================================================
# SERIE DIARIA
# ============================================================

def _crear_serie_diaria(historial_producto):

    registros = _normalizar_historial(
        historial_producto
    )

    if not registros:
        return []

    ventas_por_dia = {}

    for registro in registros:

        fecha = registro["fecha"].date()

        ventas_por_dia[fecha] = (
            ventas_por_dia.get(fecha, 0)
            + registro["cantidad"]
        )

    fecha_inicio = min(
        ventas_por_dia.keys()
    )

    fecha_fin = max(
        ventas_por_dia.keys()
    )

    serie = []

    fecha_actual = fecha_inicio

    while fecha_actual <= fecha_fin:

        cantidad = ventas_por_dia.get(
            fecha_actual,
            0
        )

        serie.append(
            {
                "fecha": fecha_actual,
                "cantidad": float(cantidad)
            }
        )

        fecha_actual += timedelta(days=1)

    return serie


# ============================================================
# FEATURES
# ============================================================

def _crear_features(serie):

    if len(serie) < MIN_DIAS_ENTRENAMIENTO:
        return None, None

    cantidades = [
        registro["cantidad"]
        for registro in serie
    ]

    X = []
    y = []

    # Necesitamos 7 días anteriores
    for i in range(7, len(serie)):

        fecha = serie[i]["fecha"]

        lag_1 = cantidades[i - 1]

        lag_7 = cantidades[i - 7]

        ventana_7 = cantidades[i - 7:i]

        promedio_7 = (
            sum(ventana_7)
            / len(ventana_7)
        )

        X.append(
            [
                fecha.weekday(),
                fecha.day,
                fecha.month,
                lag_1,
                lag_7,
                promedio_7
            ]
        )

        y.append(
            cantidades[i]
        )

    if len(X) < MIN_REGISTROS_MODELO:
        return None, None

    return (
        np.asarray(X, dtype=float),
        np.asarray(y, dtype=float)
    )


# ============================================================
# DIVISIÓN TEMPORAL
# ============================================================

def _dividir_entrenamiento_prueba(X, y):

    total = len(X)

    if total < 10:

        return (
            X,
            y,
            None,
            None
        )

    porcentaje_prueba = 0.20

    tamaño_prueba = max(
        3,
        int(total * porcentaje_prueba)
    )

    indice = total - tamaño_prueba

    X_train = X[:indice]
    y_train = y[:indice]

    X_test = X[indice:]
    y_test = y[indice:]

    return (
        X_train,
        y_train,
        X_test,
        y_test
    )


# ============================================================
# MÉTRICAS
# ============================================================

def _calcular_metricas(
    y_real,
    y_predicho
):

    if (
        y_real is None
        or y_predicho is None
    ):

        return {
            "mae": None,
            "rmse": None,
            "r2": None
        }

    mae = mean_absolute_error(
        y_real,
        y_predicho
    )

    rmse = np.sqrt(
        mean_squared_error(
            y_real,
            y_predicho
        )
    )

    if len(y_real) >= 2:

        try:
            r2 = r2_score(
                y_real,
                y_predicho
            )

        except Exception:
            r2 = None

    else:
        r2 = None

    return {
        "mae": round(
            float(mae),
            4
        ),
        "rmse": round(
            float(rmse),
            4
        ),
        "r2": (
            round(float(r2), 4)
            if r2 is not None
            else None
        )
    }


# ============================================================
# CREAR MODELOS
# ============================================================

def _crear_modelos():

    modelo_lineal = LinearRegression()

    modelo_bosque = RandomForestRegressor(
        n_estimators=300,
        max_depth=8,
        min_samples_leaf=2,
        random_state=42,
        n_jobs=-1
    )

    return (
        modelo_lineal,
        modelo_bosque
    )


# ============================================================
# EVALUACIÓN
# ============================================================

def _evaluar_modelos(X, y):

    (
        X_train,
        y_train,
        X_test,
        y_test
    ) = _dividir_entrenamiento_prueba(
        X,
        y
    )

    if X_test is None:

        return {
            "lineal": {
                "mae": None,
                "rmse": None,
                "r2": None
            },
            "bosque": {
                "mae": None,
                "rmse": None,
                "r2": None
            },
            "baseline": {
                "mae": None,
                "rmse": None,
                "r2": None
            }
        }

    (
        modelo_lineal,
        modelo_bosque
    ) = _crear_modelos()

    modelo_lineal.fit(
        X_train,
        y_train
    )

    modelo_bosque.fit(
        X_train,
        y_train
    )

    pred_lineal = (
        modelo_lineal
        .predict(X_test)
    )

    pred_bosque = (
        modelo_bosque
        .predict(X_test)
    )

    # --------------------------------------------------------
    # BASELINE
    # --------------------------------------------------------
    #
    # Para cada día de prueba utilizamos el promedio de los
    # 7 días anteriores.
    # --------------------------------------------------------

    baseline_predicciones = []

    cantidades = list(y)

    indice_inicio_test = len(y_train)

    for i in range(
        indice_inicio_test,
        len(y)
    ):

        inicio = max(
            0,
            i - 7
        )

        ventana = cantidades[
            inicio:i
        ]

        if ventana:

            baseline = (
                sum(ventana)
                / len(ventana)
            )

        else:
            baseline = 0

        baseline_predicciones.append(
            baseline
        )

    metricas_lineal = _calcular_metricas(
        y_test,
        pred_lineal
    )

    metricas_bosque = _calcular_metricas(
        y_test,
        pred_bosque
    )

    metricas_baseline = _calcular_metricas(
        y_test,
        np.asarray(
            baseline_predicciones,
            dtype=float
        )
    )

    return {

        "lineal": metricas_lineal,

        "bosque": metricas_bosque,

        "baseline": metricas_baseline

    }


# ============================================================
# FEATURE FUTURO
# ============================================================

def _crear_feature_futuro(
    fecha,
    cantidades
):

    if not cantidades:
        return None

    lag_1 = cantidades[-1]

    if len(cantidades) >= 7:

        lag_7 = cantidades[-7:]

        promedio_7 = (
            sum(lag_7)
            / len(lag_7)
        )

        ultimo_lag_7 = cantidades[-7]

    else:

        promedio_7 = (
            sum(cantidades)
            / len(cantidades)
        )

        ultimo_lag_7 = promedio_7

    return np.asarray(
        [[
            fecha.weekday(),
            fecha.day,
            fecha.month,
            lag_1,
            ultimo_lag_7,
            promedio_7
        ]],
        dtype=float
    )


# ============================================================
# PREDICCIÓN FUTURA
# ============================================================

def _predecir_futuro(
    modelo,
    serie,
    dias=DIAS_PREDICCION
):

    if not serie:
        return []

    cantidades = [
        registro["cantidad"]
        for registro in serie
    ]

    ultima_fecha = (
        serie[-1]["fecha"]
    )

    predicciones = []

    for paso in range(
        1,
        dias + 1
    ):

        fecha_futura = (
            ultima_fecha
            + timedelta(days=paso)
        )

        X_futuro = _crear_feature_futuro(
            fecha_futura,
            cantidades
        )

        prediccion = float(
            modelo.predict(
                X_futuro
            )[0]
        )

        # La demanda nunca puede ser negativa.
        prediccion = max(
            0.0,
            prediccion
        )

        prediccion = round(
            prediccion,
            2
        )

        predicciones.append(
            {
                "fecha":
                    fecha_futura.strftime(
                        "%Y-%m-%d"
                    ),

                "cantidad":
                    prediccion
            }
        )

        # Se agrega para la siguiente predicción
        cantidades.append(
            prediccion
        )

    return predicciones


# ============================================================
# BASELINE FUTURO
# ============================================================

def _predecir_baseline(
    serie,
    dias=DIAS_PREDICCION
):

    if not serie:
        return []

    cantidades = [
        registro["cantidad"]
        for registro in serie
    ]

    ultima_fecha = (
        serie[-1]["fecha"]
    )

    predicciones = []

    for paso in range(
        1,
        dias + 1
    ):

        fecha_futura = (
            ultima_fecha
            + timedelta(days=paso)
        )

        ventana = cantidades[-7:]

        if ventana:

            promedio = (
                sum(ventana)
                / len(ventana)
            )

        else:
            promedio = 0

        promedio = round(
            max(0.0, promedio),
            2
        )

        predicciones.append(
            {
                "fecha":
                    fecha_futura.strftime(
                        "%Y-%m-%d"
                    ),

                "cantidad":
                    promedio
            }
        )

        cantidades.append(
            promedio
        )

    return predicciones


# ============================================================
# SELECCIÓN DEL MODELO
# ============================================================

# ============================================================
# SELECCIÓN DEL MÉTODO
# ============================================================

def _seleccionar_modelo(metricas):
    """
    Selecciona el método de predicción utilizando:

    1. RMSE como criterio principal.
    2. MAE como criterio secundario.

    El baseline se considera un método de referencia
    y puede ser seleccionado si supera a los modelos
    de aprendizaje automático en las métricas disponibles.
    """

    candidatos = []

    for nombre in [
        "lineal",
        "bosque",
        "baseline"
    ]:

        datos = metricas.get(
            nombre
        )

        if not datos:
            continue

        rmse = datos.get(
            "rmse"
        )

        mae = datos.get(
            "mae"
        )

        if rmse is None:
            continue

        if mae is None:
            mae = float("inf")

        candidatos.append(
            (
                nombre,
                float(rmse),
                float(mae)
            )
        )

    if not candidatos:
        return "baseline"

    candidatos.sort(
        key=lambda elemento: (
            elemento[1],
            elemento[2]
        )
    )

    return candidatos[0][0]


# ============================================================
# FUNCIÓN PRINCIPAL
# ============================================================

def generar_prediccion(
    historial_producto
):

    registros = _normalizar_historial(
        historial_producto
    )

    if not registros:

        return {
            "estado": "sin_datos",

            "mensaje":
                "No existen ventas con fecha válida para este producto.",

            "num_ventas": 0,

            "dias_historicos": 0,

            "prediccion_7_dias": None,

            "metricas": None
        }

    serie = _crear_serie_diaria(
        historial_producto
    )

    if len(serie) < MIN_DIAS_ENTRENAMIENTO:

        return {

            "estado":
                "datos_insuficientes",

            "mensaje":
                (
                    f"Se requieren al menos "
                    f"{MIN_DIAS_ENTRENAMIENTO} "
                    f"días de historial para "
                    f"entrenar los modelos."
                ),

            "num_ventas":
                len(registros),

            "dias_historicos":
                len(serie),

            "prediccion_7_dias":
                None,

            "metricas":
                None
        }

    X, y = _crear_features(
        serie
    )

    if X is None or y is None:

        return {

            "estado":
                "datos_insuficientes",

            "mensaje":
                (
                    "No hay suficientes "
                    "registros para construir "
                    "el dataset de entrenamiento."
                ),

            "num_ventas":
                len(registros),

            "dias_historicos":
                len(serie),

            "prediccion_7_dias":
                None,

            "metricas":
                None
        }

    # --------------------------------------------------------
    # EVALUACIÓN
    # --------------------------------------------------------

    metricas = _evaluar_modelos(
        X,
        y
    )

    # --------------------------------------------------------
    # ENTRENAMIENTO FINAL
    # --------------------------------------------------------

    (
        modelo_lineal,
        modelo_bosque
    ) = _crear_modelos()

    modelo_lineal.fit(
        X,
        y
    )

    modelo_bosque.fit(
        X,
        y
    )

    # --------------------------------------------------------
    # PREDICCIONES
    # --------------------------------------------------------

    predicciones_lineal = (
        _predecir_futuro(
            modelo_lineal,
            serie
        )
    )

    predicciones_bosque = (
        _predecir_futuro(
            modelo_bosque,
            serie
        )
    )

    predicciones_baseline = (
        _predecir_baseline(
            serie
        )
    )

    # --------------------------------------------------------
    # TOTALES
    # --------------------------------------------------------

    total_lineal = sum(
        prediccion["cantidad"]
        for prediccion
        in predicciones_lineal
    )

    total_bosque = sum(
        prediccion["cantidad"]
        for prediccion
        in predicciones_bosque
    )

    total_baseline = sum(
        prediccion["cantidad"]
        for prediccion
        in predicciones_baseline
    )

    promedio_historico = (
        sum(
            registro["cantidad"]
            for registro in serie
        )
        / len(serie)
    )

    # --------------------------------------------------------
    # MODELO SELECCIONADO
    # --------------------------------------------------------

    modelo_seleccionado = (
        _seleccionar_modelo(
            metricas
        )
    )

    if modelo_seleccionado == "lineal":

        prediccion_seleccionada = (
            predicciones_lineal
        )

        total_seleccionado = (
            total_lineal
        )

    elif modelo_seleccionado == "bosque":

        prediccion_seleccionada = (
            predicciones_bosque
        )

        total_seleccionado = (
            total_bosque
        )

    else:

        prediccion_seleccionada = (
            predicciones_baseline
        )

        total_seleccionado = (
            total_baseline
        )

    # --------------------------------------------------------
    # RESULTADO
    # --------------------------------------------------------

    return {

        "estado":
            "ok",

        "mensaje":
            "Predicción generada correctamente.",

        "num_ventas":
            len(registros),

        "dias_historicos":
            len(serie),

        "promedio_diario":
            round(
                promedio_historico,
                2
            ),

        "prediccion_lineal_7_dias":
            round(
                total_lineal,
                2
            ),

        "prediccion_bosque_7_dias":
            round(
                total_bosque,
                2
            ),

        "prediccion_baseline_7_dias":
            round(
                total_baseline,
                2
            ),

        "modelo_seleccionado":
            modelo_seleccionado,

        "prediccion_seleccionada_7_dias":
            round(
                total_seleccionado,
                2
            ),

        "predicciones_lineal":
            predicciones_lineal,

        "predicciones_bosque":
            predicciones_bosque,

        "predicciones_baseline":
            predicciones_baseline,

        "predicciones_seleccionadas":
            prediccion_seleccionada,

        "serie_historica":
            [
                {
                    "fecha":
                        registro["fecha"].strftime(
                            "%Y-%m-%d"
                        ),

                    "cantidad":
                        round(
                            registro["cantidad"],
                            2
                        )
                }

                for registro in serie
            ],

        "metricas":
            metricas
    }


# ============================================================
# FUNCIONES DE COMPATIBILIDAD
# ============================================================

def prediccion_lineal(
    historial_producto
):

    resultado = generar_prediccion(
        historial_producto
    )

    if resultado["estado"] != "ok":
        return None

    return resultado[
        "prediccion_lineal_7_dias"
    ]


def prediccion_bosque(
    historial_producto
):

    resultado = generar_prediccion(
        historial_producto
    )

    if resultado["estado"] != "ok":
        return None

    return resultado[
        "prediccion_bosque_7_dias"
    ]